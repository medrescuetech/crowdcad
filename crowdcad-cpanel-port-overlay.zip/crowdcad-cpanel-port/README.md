# CrowdCAD cPanel Port Overlay

Files to add to a fork of `evanqua/crowdcad` to produce a cPanel-deployable Next.js standalone artifact.

Start with `CPANEL_DEPLOYMENT.md`.
